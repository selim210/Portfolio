import React from 'react';
import { useApp } from '../context/AppContext';
import { Dribbble, Instagram, Linkedin, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  const { language } = useApp();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Logo and Brief */}
          <div className="col-span-1 md:col-span-2">
            <h2 className="text-2xl font-bold mb-4">
              {language === 'en' ? 'Selim Ahmed' : 'سليم أحمد'}
            </h2>
            <p className="text-gray-400 mb-6 max-w-md">
              {language === 'en'
                ? 'Creating impactful visual designs that communicate and connect since 2011.'
                : 'إنشاء تصميمات مرئية مؤثرة تتواصل وتترابط منذ عام 2011.'}
            </p>
            <div className="flex space-x-4 rtl:space-x-reverse">
              <a href="#" className="text-gray-400 hover:text-teal-400 transition-colors" aria-label="Dribbble">
                <Dribbble size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-teal-400 transition-colors" aria-label="Instagram">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-teal-400 transition-colors" aria-label="Twitter">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-teal-400 transition-colors" aria-label="LinkedIn">
                <Linkedin size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">
              {language === 'en' ? 'Quick Links' : 'روابط سريعة'}
            </h3>
            <nav className="flex flex-col space-y-2">
              <a href="#home" className="text-gray-400 hover:text-teal-400 transition-colors">
                {language === 'en' ? 'Home' : 'الرئيسية'}
              </a>
              <a href="#about" className="text-gray-400 hover:text-teal-400 transition-colors">
                {language === 'en' ? 'About' : 'عني'}
              </a>
              <a href="#portfolio" className="text-gray-400 hover:text-teal-400 transition-colors">
                {language === 'en' ? 'Portfolio' : 'أعمالي'}
              </a>
              <a href="#contact" className="text-gray-400 hover:text-teal-400 transition-colors">
                {language === 'en' ? 'Contact' : 'اتصل بي'}
              </a>
            </nav>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4">
              {language === 'en' ? 'Services' : 'الخدمات'}
            </h3>
            <nav className="flex flex-col space-y-2">
              <a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">
                {language === 'en' ? 'Brand Identity' : 'هوية العلامة التجارية'}
              </a>
              <a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">
                {language === 'en' ? 'UI/UX Design' : 'تصميم واجهة المستخدم'}
              </a>
              <a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">
                {language === 'en' ? 'Print Design' : 'التصميم المطبوع'}
              </a>
              <a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">
                {language === 'en' ? 'Packaging' : 'تصميم العبوات'}
              </a>
            </nav>
          </div>
        </div>

        <div className="pt-8 border-t border-gray-800 text-center text-gray-500 text-sm">
          <p>
            {language === 'en'
              ? `© ${currentYear} Selim Ahmed. All rights reserved.`
              : `© ${currentYear} سليم أحمد. جميع الحقوق محفوظة.`}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;