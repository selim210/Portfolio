import React from 'react';
import { ArrowDownCircle, ExternalLink } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { heroContent } from '../data/portfolio';

const HeroSection: React.FC = () => {
  const { language } = useApp();

  const handleScroll = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      id="home" 
      className="relative min-h-screen pt-20 flex items-center bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 overflow-hidden"
    >
      {/* Background Elements - Decorative */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-32 -left-32 w-64 h-64 rounded-full bg-teal-200 dark:bg-teal-900/40 blur-3xl opacity-40"></div>
        <div className="absolute top-1/3 -right-32 w-80 h-80 rounded-full bg-amber-200 dark:bg-amber-900/30 blur-3xl opacity-30"></div>
        <div className="absolute bottom-0 left-1/4 w-96 h-96 rounded-full bg-blue-200 dark:bg-blue-900/30 blur-3xl opacity-20"></div>
      </div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="flex flex-col-reverse md:flex-row items-center">
          {/* Content */}
          <div className="w-full md:w-1/2 text-center md:text-left md:rtl:text-right mt-8 md:mt-0">
            <h2 className="text-xl md:text-2xl font-medium text-teal-600 dark:text-teal-400 mb-4 animate-fadeIn opacity-0" style={{animationDelay: '0.2s', animationFillMode: 'forwards'}}>
              {heroContent.title[language]}
            </h2>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-6 animate-fadeIn opacity-0" style={{animationDelay: '0.4s', animationFillMode: 'forwards'}}>
              {heroContent.name[language]}
            </h1>
            <p className="text-lg md:text-xl text-gray-700 dark:text-gray-300 mb-8 max-w-xl mx-auto md:mx-0 md:rtl:ml-auto animate-fadeIn opacity-0" style={{animationDelay: '0.6s', animationFillMode: 'forwards'}}>
              {heroContent.subtitle[language]}
            </p>
            <div className="flex flex-wrap gap-4 justify-center md:justify-start md:rtl:justify-end animate-fadeIn opacity-0" style={{animationDelay: '0.8s', animationFillMode: 'forwards'}}>
              <button 
                onClick={() => handleScroll('portfolio')}
                className="px-6 py-3 bg-teal-600 hover:bg-teal-700 text-white font-medium rounded-lg transition-all shadow-lg hover:shadow-xl flex items-center gap-2"
              >
                {heroContent.cta[language]}
                <ExternalLink size={18} />
              </button>
              <button 
                onClick={() => handleScroll('contact')}
                className="px-6 py-3 border border-gray-300 dark:border-gray-700 hover:border-teal-600 dark:hover:border-teal-500 text-gray-900 dark:text-white hover:text-teal-600 dark:hover:text-teal-400 font-medium rounded-lg transition-all"
              >
                {heroContent.contact[language]}
              </button>
            </div>
          </div>

          {/* Hero Image */}
          <div className="w-full md:w-1/2 p-4 animate-fadeIn opacity-0" style={{animationDelay: '0.6s', animationFillMode: 'forwards'}}>
            <div className="relative mx-auto max-w-md">
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-teal-500 to-blue-600 transform rotate-6 opacity-20 dark:opacity-30 blur-sm"></div>
              <img 
                src="https://images.pexels.com/photos/6626903/pexels-photo-6626903.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Selim Ahmed - Graphic Designer" 
                className="relative z-10 rounded-2xl shadow-xl w-full h-auto object-cover"
              />
              <div className="absolute -bottom-4 -right-4 w-24 h-24 rounded-xl bg-amber-400 dark:bg-amber-600 shadow-lg transform rotate-12"></div>
              <div className="absolute -top-4 -left-4 w-16 h-16 rounded-lg bg-teal-500 dark:bg-teal-600 shadow-lg transform -rotate-12"></div>
            </div>
          </div>
        </div>

        {/* Scroll Down Indicator */}
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
          <button 
            onClick={() => handleScroll('about')}
            className="text-gray-500 dark:text-gray-400 hover:text-teal-600 dark:hover:text-teal-400 transition-colors"
            aria-label="Scroll down"
          >
            <ArrowDownCircle size={36} />
          </button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;