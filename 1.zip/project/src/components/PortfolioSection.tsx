import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { projects } from '../data/portfolio';
import { ExternalLink } from 'lucide-react';

const PortfolioSection: React.FC = () => {
  const { language } = useApp();
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [selectedProject, setSelectedProject] = useState<string | null>(null);

  // Extract unique categories
  const categories = Array.from(
    new Set(projects.map((project) => project.category.en))
  );

  // Filter projects by category
  const filteredProjects = activeCategory
    ? projects.filter((project) => project.category.en === activeCategory)
    : projects;

  // Find selected project details
  const selectedProjectDetails = selectedProject
    ? projects.find((project) => project.id === selectedProject)
    : null;

  return (
    <section id="portfolio" className="py-20 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            {language === 'en' ? 'My Portfolio' : 'أعمالي'}
          </h2>
          <div className="w-24 h-1 bg-teal-500 mx-auto mb-8"></div>
          <p className="text-lg text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">
            {language === 'en'
              ? 'A showcase of my recent projects and creative works, demonstrating my skills and expertise in graphic design.'
              : 'عرض لمشاريعي الأخيرة وأعمالي الإبداعية، مما يدل على مهاراتي وخبرتي في التصميم الجرافيكي.'}
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center mb-12 gap-2">
          <button
            onClick={() => setActiveCategory(null)}
            className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${
              activeCategory === null
                ? 'bg-teal-600 text-white'
                : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
            }`}
          >
            {language === 'en' ? 'All' : 'الكل'}
          </button>
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${
                activeCategory === category
                  ? 'bg-teal-600 text-white'
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
              }`}
            >
              {language === 'en' ? category : projects.find(p => p.category.en === category)?.category.ar}
            </button>
          ))}
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="group relative overflow-hidden rounded-lg shadow-md cursor-pointer transform transition-all duration-300 hover:shadow-xl hover:-translate-y-1"
              onClick={() => setSelectedProject(project.id)}
            >
              <img
                src={project.imageUrl}
                alt={project.title[language]}
                className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-5">
                <h3 className="text-white text-xl font-bold mb-1">
                  {project.title[language]}
                </h3>
                <p className="text-gray-200 text-sm">
                  {project.category[language]} | {project.year}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Project Modal */}
        {selectedProjectDetails && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70" onClick={() => setSelectedProject(null)}>
            <div
              className="relative bg-white dark:bg-gray-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                className="absolute top-4 right-4 z-10 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                onClick={() => setSelectedProject(null)}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18"></line>
                  <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
              </button>

              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="h-72 md:h-full">
                  <img
                    src={selectedProjectDetails.imageUrl}
                    alt={selectedProjectDetails.title[language]}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6 md:p-8 flex flex-col">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                    {selectedProjectDetails.title[language]}
                  </h3>
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400 mb-4">
                    <span className="px-3 py-1 bg-teal-100 dark:bg-teal-900/30 text-teal-800 dark:text-teal-300 rounded-full mr-2">
                      {selectedProjectDetails.category[language]}
                    </span>
                    <span>{selectedProjectDetails.year}</span>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 mb-6 flex-grow">
                    {selectedProjectDetails.description[language]}
                  </p>
                  <button className="flex items-center justify-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-medium py-2 px-4 rounded-lg transition-colors">
                    {language === 'en' ? 'View Full Project' : 'عرض المشروع كاملاً'}
                    <ExternalLink size={16} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default PortfolioSection;