import React from 'react';
import { useApp } from '../context/AppContext';
import { skills } from '../data/portfolio';

const SkillsSection: React.FC = () => {
  const { language } = useApp();

  return (
    <section id="skills" className="py-20 bg-white dark:bg-gray-800">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            {language === 'en' ? 'My Skills' : 'مهاراتي'}
          </h2>
          <div className="w-24 h-1 bg-teal-500 mx-auto mb-8"></div>
          <p className="text-lg text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">
            {language === 'en'
              ? 'With over a decade of experience, I\'ve developed expertise in a wide range of design disciplines and tools.'
              : 'مع أكثر من عقد من الخبرة، طورت خبرة في مجموعة واسعة من تخصصات وأدوات التصميم.'}
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          {skills.map((skill, index) => (
            <div key={index} className="mb-8">
              <div className="flex justify-between mb-2">
                <span className="font-medium text-gray-800 dark:text-gray-200">
                  {skill.name[language]}
                </span>
                <span className="text-teal-600 dark:text-teal-400 font-medium">
                  {skill.level}%
                </span>
              </div>
              <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-teal-500 to-teal-600 rounded-full"
                  style={{ 
                    width: `${skill.level}%`,
                    animation: `growWidth 1.5s ease-out forwards`,
                    transformOrigin: 'left'
                  }}
                ></div>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Design Elements */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Design Philosophy */}
          <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-lg shadow-sm transform transition-transform duration-300 hover:-translate-y-1">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
              {language === 'en' ? 'Design Thinking' : 'تفكير التصميم'}
            </h3>
            <p className="text-gray-700 dark:text-gray-300">
              {language === 'en'
                ? 'I approach each project with a strategic, user-centered perspective, focusing on solving real problems.'
                : 'أتناول كل مشروع بمنظور استراتيجي يركز على المستخدم، مع التركيز على حل المشكلات الحقيقية.'}
            </p>
          </div>

          {/* Attention to Detail */}
          <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-lg shadow-sm transform transition-transform duration-300 hover:-translate-y-1">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
              {language === 'en' ? 'Detail Oriented' : 'الاهتمام بالتفاصيل'}
            </h3>
            <p className="text-gray-700 dark:text-gray-300">
              {language === 'en'
                ? 'The smallest details make the biggest difference. I ensure every pixel serves a purpose in my designs.'
                : 'أصغر التفاصيل تصنع أكبر الفروق. أضمن أن كل بكسل يخدم غرضًا في تصميماتي.'}
            </p>
          </div>

          {/* Creativity */}
          <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-lg shadow-sm transform transition-transform duration-300 hover:-translate-y-1">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
              {language === 'en' ? 'Creative Problem Solving' : 'حل المشكلات بإبداع'}
            </h3>
            <p className="text-gray-700 dark:text-gray-300">
              {language === 'en'
                ? 'I combine analytical thinking with creative innovation to develop unique design solutions.'
                : 'أجمع بين التفكير التحليلي والابتكار الإبداعي لتطوير حلول تصميم فريدة.'}
            </p>
          </div>

          {/* Continuous Learning */}
          <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-lg shadow-sm transform transition-transform duration-300 hover:-translate-y-1">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
              {language === 'en' ? 'Continuous Growth' : 'النمو المستمر'}
            </h3>
            <p className="text-gray-700 dark:text-gray-300">
              {language === 'en'
                ? 'I stay current with industry trends and continuously expand my skill set to deliver cutting-edge designs.'
                : 'أواكب اتجاهات الصناعة وأوسع مجموعة مهاراتي باستمرار لتقديم تصميمات متطورة.'}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;