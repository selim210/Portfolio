import React from 'react';
import { useApp } from '../context/AppContext';
import { aboutContent } from '../data/portfolio';
import { Briefcase, Users, CheckCircle } from 'lucide-react';

const AboutSection: React.FC = () => {
  const { language } = useApp();

  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-800">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            {aboutContent.title[language]}
          </h2>
          <div className="w-24 h-1 bg-teal-500 mx-auto mb-8"></div>
        </div>

        <div className="flex flex-col md:flex-row gap-12 items-center">
          {/* Image Column */}
          <div className="w-full md:w-2/5">
            <div className="relative">
              {/* Main Image */}
              <div className="relative z-10 overflow-hidden rounded-lg shadow-xl">
                <img 
                  src="https://images.pexels.com/photos/7147559/pexels-photo-7147559.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                  alt="Selim Ahmed Working" 
                  className="w-full h-auto transform transition-transform duration-700 hover:scale-105"
                />
              </div>
              
              {/* Decorative Elements */}
              <div className="absolute top-8 -left-8 w-32 h-32 md:w-48 md:h-48 rounded-lg bg-amber-400/30 dark:bg-amber-600/20 -z-10"></div>
              <div className="absolute -bottom-8 -right-8 w-40 h-40 md:w-64 md:h-64 rounded-lg bg-teal-400/30 dark:bg-teal-600/20 -z-10"></div>

              {/* Experience Badge */}
              <div className="absolute -bottom-6 left-6 bg-white dark:bg-gray-700 shadow-xl rounded-lg p-4 z-20">
                <p className="text-3xl md:text-4xl font-bold text-teal-600 dark:text-teal-400">12+</p>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  {aboutContent.experience[language]}
                </p>
              </div>
            </div>
          </div>

          {/* Content Column */}
          <div className="w-full md:w-3/5">
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <div className="whitespace-pre-line text-gray-700 dark:text-gray-300">
                {aboutContent.bio[language]}
              </div>
            </div>

            {/* Stats Section */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
              <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-lg shadow-sm">
                <div className="text-teal-600 dark:text-teal-400 mb-3">
                  <Briefcase size={32} />
                </div>
                <h3 className="text-3xl font-bold text-gray-900 dark:text-white">250+</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  {aboutContent.projects[language]}
                </p>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-lg shadow-sm">
                <div className="text-teal-600 dark:text-teal-400 mb-3">
                  <Users size={32} />
                </div>
                <h3 className="text-3xl font-bold text-gray-900 dark:text-white">80+</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  {aboutContent.clients[language]}
                </p>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-lg shadow-sm">
                <div className="text-teal-600 dark:text-teal-400 mb-3">
                  <CheckCircle size={32} />
                </div>
                <h3 className="text-3xl font-bold text-gray-900 dark:text-white">98%</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  {language === 'en' ? 'Client Satisfaction' : 'رضا العملاء'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;