import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { testimonials } from '../data/portfolio';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const TestimonialsSection: React.FC = () => {
  const { language } = useApp();
  const [activeIndex, setActiveIndex] = useState(0);

  const nextTestimonial = () => {
    setActiveIndex((current) => (current + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setActiveIndex((current) => 
      current === 0 ? testimonials.length - 1 : current - 1
    );
  };

  return (
    <section id="testimonials" className="py-20 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            {language === 'en' ? 'Client Testimonials' : 'آراء العملاء'}
          </h2>
          <div className="w-24 h-1 bg-teal-500 mx-auto mb-8"></div>
          <p className="text-lg text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">
            {language === 'en'
              ? 'What my clients have to say about working with me and the results of our collaborations.'
              : 'ما يقوله عملائي عن العمل معي ونتائج تعاوننا.'}
          </p>
        </div>

        <div className="max-w-4xl mx-auto relative">
          {/* Large Quote Icon (Decorative) */}
          <div className="absolute -top-8 left-0 text-gray-200 dark:text-gray-700 opacity-50">
            <Quote size={64} />
          </div>

          {/* Testimonial Cards */}
          <div className="relative h-[360px] overflow-hidden">
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.id}
                className={`absolute inset-0 transition-all duration-700 transform ${
                  index === activeIndex
                    ? 'translate-x-0 opacity-100'
                    : index < activeIndex
                    ? '-translate-x-full opacity-0'
                    : 'translate-x-full opacity-0'
                }`}
              >
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 md:p-10 flex flex-col md:flex-row items-center md:items-start gap-8">
                  <div className="w-24 h-24 md:w-32 md:h-32 flex-shrink-0">
                    <img
                      src={testimonial.imageUrl}
                      alt={testimonial.name[language]}
                      className="w-full h-full object-cover rounded-full border-4 border-teal-100 dark:border-teal-900"
                    />
                  </div>
                  <div className="flex flex-col flex-grow">
                    <p className="text-gray-700 dark:text-gray-300 text-lg italic mb-6">
                      {testimonial.text[language]}
                    </p>
                    <div className="mt-auto">
                      <h4 className="text-xl font-bold text-gray-900 dark:text-white">
                        {testimonial.name[language]}
                      </h4>
                      <p className="text-teal-600 dark:text-teal-400">
                        {testimonial.role[language]}, {testimonial.company[language]}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation Buttons */}
          <div className="flex justify-center mt-8 gap-4">
            <button
              onClick={prevTestimonial}
              className="p-2 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-teal-500 hover:text-white transition-colors"
              aria-label="Previous testimonial"
            >
              <ChevronLeft size={24} />
            </button>
            
            {/* Dots Indicator */}
            <div className="flex items-center gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all ${
                    index === activeIndex
                      ? 'bg-teal-600 w-6'
                      : 'bg-gray-300 dark:bg-gray-600 hover:bg-teal-400 dark:hover:bg-teal-700'
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                ></button>
              ))}
            </div>
            
            <button
              onClick={nextTestimonial}
              className="p-2 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-teal-500 hover:text-white transition-colors"
              aria-label="Next testimonial"
            >
              <ChevronRight size={24} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;