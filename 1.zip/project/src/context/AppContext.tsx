import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { Language, Theme } from '../types';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  isMenuOpen: boolean;
  setIsMenuOpen: (isOpen: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  // Check if user has a saved preference, otherwise detect based on browser language
  const initialLanguage = (): Language => {
    const savedLanguage = localStorage.getItem('language') as Language;
    if (savedLanguage) return savedLanguage;
    
    const browserLanguage = navigator.language.split('-')[0];
    return browserLanguage === 'ar' ? 'ar' : 'en';
  };

  // Check if user has a saved theme preference, otherwise use system preference
  const initialTheme = (): Theme => {
    const savedTheme = localStorage.getItem('theme') as Theme;
    if (savedTheme) return savedTheme;
    
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  };

  const [language, setLanguageState] = useState<Language>(initialLanguage());
  const [theme, setThemeState] = useState<Theme>(initialTheme());
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Update the language and save to localStorage
  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('language', lang);
    // Update the document direction
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  };

  // Update the theme and save to localStorage
  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme);
    localStorage.setItem('theme', newTheme);
    
    // Update the document class
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  // Set initial document direction and theme on mount
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    }
  }, []);

  const value = {
    language,
    setLanguage,
    theme,
    setTheme,
    isMenuOpen,
    setIsMenuOpen
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};