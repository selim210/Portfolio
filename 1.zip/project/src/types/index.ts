export interface NavItem {
  label: {
    en: string;
    ar: string;
  };
  href: string;
}

export interface LanguageStrings {
  [key: string]: {
    en: string;
    ar: string;
  };
}

export interface ProjectItem {
  id: string;
  title: {
    en: string;
    ar: string;
  };
  category: {
    en: string;
    ar: string;
  };
  description: {
    en: string;
    ar: string;
  };
  imageUrl: string;
  year: number;
}

export interface SkillItem {
  name: {
    en: string;
    ar: string;
  };
  level: number; // 0-100
  icon?: string;
}

export interface TestimonialItem {
  id: string;
  name: {
    en: string;
    ar: string;
  };
  role: {
    en: string;
    ar: string;
  };
  company: {
    en: string;
    ar: string;
  };
  text: {
    en: string;
    ar: string;
  };
  imageUrl: string;
}

export type Language = 'en' | 'ar';
export type Theme = 'light' | 'dark';