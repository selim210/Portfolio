import { NavItem, ProjectItem, SkillItem, TestimonialItem, LanguageStrings } from '../types';

export const navItems: NavItem[] = [
  {
    label: {
      en: 'Home',
      ar: 'الرئيسية'
    },
    href: '#home'
  },
  {
    label: {
      en: 'About',
      ar: 'عني'
    },
    href: '#about'
  },
  {
    label: {
      en: 'Portfolio',
      ar: 'أعمالي'
    },
    href: '#portfolio'
  },
  {
    label: {
      en: 'Skills',
      ar: 'المهارات'
    },
    href: '#skills'
  },
  {
    label: {
      en: 'Testimonials',
      ar: 'آراء العملاء'
    },
    href: '#testimonials'
  },
  {
    label: {
      en: 'Contact',
      ar: 'اتصل بي'
    },
    href: '#contact'
  }
];

export const heroContent: LanguageStrings = {
  name: {
    en: 'Selim Ahmed',
    ar: 'سليم أحمد'
  },
  title: {
    en: 'Senior Graphic Designer',
    ar: 'مصمم جرافيك كبير'
  },
  subtitle: {
    en: 'Creating visual stories that capture attention and convey meaning.',
    ar: 'أنشئ قصصًا مرئية تجذب الانتباه وتنقل المعنى.'
  },
  cta: {
    en: 'View My Work',
    ar: 'عرض أعمالي'
  },
  contact: {
    en: 'Contact Me',
    ar: 'اتصل بي'
  }
};

export const aboutContent: LanguageStrings = {
  title: {
    en: 'About Me',
    ar: 'عني'
  },
  bio: {
    en: `With over 12 years of experience in the design industry, I've developed a keen eye for detail and a passion for creating compelling visual stories. My journey as a graphic designer has allowed me to collaborate with brands across various industries, helping them communicate their message effectively through thoughtful design.

    My approach combines strategic thinking with creative execution, ensuring that each project not only looks stunning but also achieves its intended goals. I believe that great design should be both beautiful and functional, creating meaningful connections between brands and their audiences.

    When I'm not designing, you'll find me exploring new creative techniques, attending design workshops, or finding inspiration in the world around me.`,
    ar: `مع أكثر من 12 عامًا من الخبرة في صناعة التصميم، طوّرت عينًا حادة للتفاصيل وشغفًا بإنشاء قصص مرئية مقنعة. سمحت لي رحلتي كمصمم جرافيك بالتعاون مع العلامات التجارية عبر مختلف الصناعات، مساعدتهم على توصيل رسالتهم بفعالية من خلال التصميم المدروس.

    يجمع نهجي بين التفكير الاستراتيجي والتنفيذ الإبداعي، مما يضمن أن كل مشروع لا يبدو مذهلاً فحسب، بل يحقق أيضًا أهدافه المقصودة. أؤمن بأن التصميم الرائع يجب أن يكون جميلاً وعمليًا، وأن يخلق روابط هادفة بين العلامات التجارية وجماهيرها.

    عندما لا أكون منشغلاً بالتصميم، ستجدني أستكشف تقنيات إبداعية جديدة، أو أحضر ورش عمل تصميمية، أو أجد الإلهام في العالم من حولي.`
  },
  experience: {
    en: 'Years of Experience',
    ar: 'سنوات الخبرة'
  },
  clients: {
    en: 'Clients Worldwide',
    ar: 'عملاء حول العالم'
  },
  projects: {
    en: 'Projects Completed',
    ar: 'المشاريع المنجزة'
  }
};

export const projects: ProjectItem[] = [
  {
    id: 'proj1',
    title: {
      en: 'Brand Identity for Zenith',
      ar: 'هوية العلامة التجارية لزينيث'
    },
    category: {
      en: 'Branding',
      ar: 'العلامة التجارية'
    },
    description: {
      en: 'Complete brand identity redesign for a tech startup, including logo, color palette, typography, and brand guidelines.',
      ar: 'إعادة تصميم كاملة لهوية العلامة التجارية لشركة ناشئة في مجال التكنولوجيا، تشمل الشعار ولوحة الألوان والطباعة وإرشادات العلامة التجارية.'
    },
    imageUrl: 'https://images.pexels.com/photos/4066041/pexels-photo-4066041.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2023
  },
  {
    id: 'proj2',
    title: {
      en: 'Packaging Design for Bloom',
      ar: 'تصميم عبوات لبلوم'
    },
    category: {
      en: 'Packaging',
      ar: 'تصميم العبوات'
    },
    description: {
      en: 'Premium packaging design for a cosmetics line, with a focus on sustainability and luxury appeal.',
      ar: 'تصميم عبوات متميزة لخط مستحضرات تجميل، مع التركيز على الاستدامة وجاذبية الفخامة.'
    },
    imageUrl: 'https://images.pexels.com/photos/3735206/pexels-photo-3735206.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2022
  },
  {
    id: 'proj3',
    title: {
      en: 'Annual Report for Global Finance',
      ar: 'التقرير السنوي للتمويل العالمي'
    },
    category: {
      en: 'Editorial',
      ar: 'تحريري'
    },
    description: {
      en: 'Award-winning annual report design that transformed complex financial data into visually engaging storytelling.',
      ar: 'تصميم تقرير سنوي حائز على جوائز حول البيانات المالية المعقدة إلى سرد قصص جذاب بصريًا.'
    },
    imageUrl: 'https://images.pexels.com/photos/4097159/pexels-photo-4097159.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2023
  },
  {
    id: 'proj4',
    title: {
      en: 'Campaign for Ocean Conservation',
      ar: 'حملة للحفاظ على المحيطات'
    },
    category: {
      en: 'Advertising',
      ar: 'إعلان'
    },
    description: {
      en: 'Impactful visual campaign for a non-profit organization focused on ocean conservation efforts.',
      ar: 'حملة بصرية مؤثرة لمنظمة غير ربحية تركز على جهود الحفاظ على المحيطات.'
    },
    imageUrl: 'https://images.pexels.com/photos/4210787/pexels-photo-4210787.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2022
  },
  {
    id: 'proj5',
    title: {
      en: 'UI Design for Fintech App',
      ar: 'تصميم واجهة المستخدم لتطبيق التكنولوجيا المالية'
    },
    category: {
      en: 'UI/UX',
      ar: 'واجهة المستخدم/تجربة المستخدم'
    },
    description: {
      en: 'Modern and intuitive interface design for a leading financial technology platform.',
      ar: 'تصميم واجهة حديثة وبديهية لمنصة تكنولوجيا مالية رائدة.'
    },
    imageUrl: 'https://images.pexels.com/photos/4195327/pexels-photo-4195327.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2023
  },
  {
    id: 'proj6',
    title: {
      en: 'Festival Poster Series',
      ar: 'سلسلة ملصقات المهرجان'
    },
    category: {
      en: 'Print Design',
      ar: 'تصميم مطبوع'
    },
    description: {
      en: 'Vibrant poster series for an international arts festival, featuring custom illustrations and typography.',
      ar: 'سلسلة ملصقات نابضة بالحياة لمهرجان فنون دولي، تتميز برسوم توضيحية وطباعة مخصصة.'
    },
    imageUrl: 'https://images.pexels.com/photos/5626219/pexels-photo-5626219.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    year: 2022
  }
];

export const skills: SkillItem[] = [
  {
    name: {
      en: 'Adobe Photoshop',
      ar: 'أدوبي فوتوشوب'
    },
    level: 95
  },
  {
    name: {
      en: 'Adobe Illustrator',
      ar: 'أدوبي إليستريتور'
    },
    level: 90
  },
  {
    name: {
      en: 'Adobe InDesign',
      ar: 'أدوبي إن ديزاين'
    },
    level: 85
  },
  {
    name: {
      en: 'Figma',
      ar: 'فيجما'
    },
    level: 80
  },
  {
    name: {
      en: 'UI/UX Design',
      ar: 'تصميم واجهة المستخدم/تجربة المستخدم'
    },
    level: 85
  },
  {
    name: {
      en: 'Typography',
      ar: 'فن الطباعة'
    },
    level: 90
  },
  {
    name: {
      en: 'Brand Strategy',
      ar: 'استراتيجية العلامة التجارية'
    },
    level: 85
  },
  {
    name: {
      en: 'Motion Graphics',
      ar: 'الرسومات المتحركة'
    },
    level: 75
  }
];

export const testimonials: TestimonialItem[] = [
  {
    id: 'test1',
    name: {
      en: 'Sarah Johnson',
      ar: 'سارة جونسون'
    },
    role: {
      en: 'Marketing Director',
      ar: 'مديرة التسويق'
    },
    company: {
      en: 'Elevate Brands',
      ar: 'إيليفيت براندز'
    },
    text: {
      en: "Selim transformed our brand identity with exceptional creativity and attention to detail. His strategic approach to design has significantly improved our audience engagement and brand recognition.",
      ar: "قام سليم بتحويل هوية علامتنا التجارية بإبداع استثنائي واهتمام بالتفاصيل. أدى نهجه الاستراتيجي في التصميم إلى تحسين مشاركة جمهورنا والتعرف على العلامة التجارية بشكل كبير."
    },
    imageUrl: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: 'test2',
    name: {
      en: 'Mohammed Al-Farsi',
      ar: 'محمد الفارسي'
    },
    role: {
      en: 'CEO',
      ar: 'الرئيس التنفيذي'
    },
    company: {
      en: 'Innovate Tech',
      ar: 'إنوفيت تك'
    },
    text: {
      en: "Working with Selim on our rebranding project was a game-changer. He understood our vision perfectly and delivered designs that exceeded our expectations. His communication and professionalism made the process smooth and enjoyable.",
      ar: "كان العمل مع سليم في مشروع إعادة تصميم علامتنا التجارية بمثابة نقلة نوعية. لقد فهم رؤيتنا بشكل مثالي وقدم تصميمات تجاوزت توقعاتنا. جعل تواصله واحترافه العملية سلسة وممتعة."
    },
    imageUrl: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: 'test3',
    name: {
      en: 'Leila Hakimi',
      ar: 'ليلى حكيمي'
    },
    role: {
      en: 'Art Director',
      ar: 'مديرة فنية'
    },
    company: {
      en: 'Canvas Studio',
      ar: 'استوديو كانفاس'
    },
    text: {
      en: "Selim is a rare talent who combines artistic vision with business acumen. His designs not only look beautiful but also strategically support marketing objectives. I've collaborated with him on multiple projects, and he consistently delivers excellence.",
      ar: "سليم موهبة نادرة تجمع بين الرؤية الفنية والفطنة التجارية. تصميماته لا تبدو جميلة فحسب، بل تدعم أيضًا أهداف التسويق بشكل استراتيجي. لقد تعاونت معه في مشاريع متعددة، وهو يقدم التميز باستمرار."
    },
    imageUrl: 'https://images.pexels.com/photos/762080/pexels-photo-762080.jpeg?auto=compress&cs=tinysrgb&w=600'
  }
];

export const contactContent: LanguageStrings = {
  title: {
    en: 'Get In Touch',
    ar: 'تواصل معي'
  },
  subtitle: {
    en: "I'm always open to discussing new projects, creative ideas or opportunities to be part of your vision.",
    ar: "أنا دائمًا منفتح لمناقشة مشاريع جديدة، أفكار إبداعية أو فرص لأكون جزءًا من رؤيتك."
  },
  nameLabel: {
    en: 'Your Name',
    ar: 'اسمك'
  },
  emailLabel: {
    en: 'Your Email',
    ar: 'بريدك الإلكتروني'
  },
  messageLabel: {
    en: 'Your Message',
    ar: 'رسالتك'
  },
  submitButton: {
    en: 'Send Message',
    ar: 'إرسال الرسالة'
  },
  address: {
    en: 'Dubai Design District, Building 7',
    ar: 'حي دبي للتصميم، مبنى 7'
  },
  phone: {
    en: '+971 50 123 4567',
    ar: '٤٥٦٧ ١٢٣ ٥٠ ٩٧١+'
  },
  email: {
    en: 'contact@selimahmed.com',
    ar: 'contact@selimahmed.com'
  }
};